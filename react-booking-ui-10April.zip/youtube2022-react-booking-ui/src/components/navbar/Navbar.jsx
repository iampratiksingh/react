import { useNavigate } from "react-router-dom";
import "./navbar.css"

const Navbar = () => {
  
  const navigate = useNavigate();
  const registerHandleClick = () => {
    navigate("/UserRegister");
  };

  const handleClick = () => {
    navigate("/Userlogin");
  };

  return (
    <div className="navbar">
      <div className="navContainer">
        <span className="logo">Checkin.com</span>
        <div className="navItems">
        <button className="navButton" onClick={registerHandleClick}>Register</button>
        <button className="navButton" onClick={handleClick}>Login</button>
        </div>
      </div>
    </div>
  )
}

export default Navbar