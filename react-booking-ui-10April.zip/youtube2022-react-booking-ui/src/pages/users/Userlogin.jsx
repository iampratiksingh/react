import './Userlogin.css';
// import React, { Component, useState } from "react";
import { Link } from "react-router-dom";
import { useState } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom"

const Userlogin = () => {

    const [form, setForm] = useState({ email: "", password: "" })
    let history = useNavigate()
    const handleClick = async () => {
        console.log('form value: ', form)
        alert(form.email);
        const url = "https://checkindotcomapi.azurewebsites.net/api/Auth/Login"
     
        const formdata = {
            Email: form.email,
            Password: form.password
        }
        alert(form.password);
        await axios.post(url, formdata)
            .then((response) => {
                console.log("ttttyyyy",response.message)
                if (response.status === 200) {
                    alert("User Registered, moving to Login Page");
                    history('Home')
                }
            }).catch((error) => {
              alert(error.message);
                //console.log("logg",error.response.data)
                alert(error.response.data);
            })

    }

    return (
        <div>
        <div className="container">
              <form action="#">
                <div className="title">Login</div>
                <div className="input-box underline">
                        <input type="text" onChange={(e) => { setForm(prevState => ({ ...prevState, email: e.target.value })) }} placeholder="Enter Your Email" required/>
                  <div className="underline"></div>
                </div>
                <div className="input-box">
                        <input type="password" onChange={(e) => { setForm(prevState => ({ ...prevState, password: e.target.value })) }} placeholder="Enter Your Password" required/>
                  <div className="underline"></div>
                </div>
                <div className="input-box button">
                        <input type="submit" onClick={() => handleClick()} name="" value="Sign In"/>
                </div>
              </form>
                <div className="option">or Connect With Social Media</div>
                <div>
                <div>
                <div className="twitter">
                  <a href="#"><i className="fab fa-twitter"></i>Sign in With Twitter</a>
                </div>
                <div className="facebook">
                  <a href="#"><i className="fab fa-facebook-f"></i>Sign in With Facebook</a>
                </div>
                </div>
              
            </div>
            </div>
            <div>
                <span className="newUser">    New User? <br/>
                    <Link to='/UserRegistration' className="newUserButton">Click</Link>
                    here to register</span>
                </div>
           
        
    </div>
    );

};

export default Userlogin;
