import {useState } from "react";
import './UserRegister.css';
// import React, { Component, useState } from "react";
import { Link } from "react-router-dom"
import { useNavigate } from "react-router-dom"
//import { axios } from "../../../../../../node_modules/axios/index";
import axios from 'axios';
/*import ReactDOM from "react-dom/client";*/

function UserRegister(){ 
    let history = useNavigate()
    const [form, setForm] = useState({ firstName: "", lastName: "", email: "", password: "" })

    const handleClick = async () => {
        debugger;
        console.log('form value: ', form)
        const url = "https://checkindotcomapi.azurewebsites.net/api/Auth/register"
        
        const formdata = {
            Email: form.email,
            FirstName: form.firstName,
            LastName: form.lastName,
            Password: form.password,
            ContactNumber: '1234567890',
            DocumentNumber:'1234567890',
            DocumentType:'test',
            Address:'testadd',
            PostalCode: '567888',
            Country: 'India',
            State: 'UP',
            City: 'Noida'

        }

        await axios.post(url, formdata)
            .then((response) => {
                console.log(response)
                if (response.status === 200) { 
                    alert("User Registered Successfully");
                    //history('/')
                }
            }).catch((error) => {
                console.log("logg", error)
                alert(error);
            })

    }
    
        return (
            <div>
                <head>
                    <meta charset="UTF-8" />
                    <link rel="stylesheet" href="style.css" />
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                </head>

                <div className="container">
                    <form action="#" id="RegisterForm" >
                        <div className="title">Create an CheckIn.com Account</div>
                        <div className="input-box underline">
                            <input type="text" onChange={(e) => { setForm(prevState => ({...prevState, firstName:e.target.value }))}} placeholder="FirstName" required/>
                            <div className="underline"></div>
                        </div>
                        <div className="input-box underline">
                            <input type="text" onChange={(e) => { setForm(prevState => ({ ...prevState, lastName: e.target.value })) }} placeholder="LastName" required/>
                            <div className="underline"></div>
                        </div>
                        <div className="input-box underline">
                            <input type="email" onChange={(e) => { setForm(prevState => ({ ...prevState, email: e.target.value })) }} placeholder="Enter Your Email" required/>
                            <div className="underline"></div>
                        </div>
                        <div className="input-box">
                            <input type="password" onChange={(e) => { setForm(prevState => ({ ...prevState, password: e.target.value })) }} placeholder="Enter Your Password" required/>
                            <div className="underline"></div>
                        </div>
                        <div className="input-box">
                            <input type="password"  placeholder="Confirm Password" required/>
                            <div className="underline"></div>
                        </div>
                        <div>
                            <input type="checkbox" placeholder="Term and Condition"  />
                            <div className="underline"></div>
                        </div>
                        <div className="input-box button">
                            <input type="submit" onClick={()=>handleClick()} name="" value="Sign In" />
                        </div>
                    </form>
                </div>
                <div>
                    <span className="newUser">    Already Registered? <br />
                        <Link to='/' className="newUserButton">Click</Link>
                        here to login</span>
                </div>
            </div>
        );
    
}

//const root = ReactDOM.hydrateroot(document.getElementById("FormRegister"));



export default UserRegister;
